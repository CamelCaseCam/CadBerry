# gil-syntax-highlighting README

This is just a quick extension I threw together to give GIL proper syntax highlighting to stop my eyes from bleeding. Feel free to modify it or improve it, it's under the same license as the rest of GIL.

## Features

It highlights GIL code so it isn't just all white (or black if you're a heretic who uses light mode)

## Requirements

You probably want to have the GIL compiler installed, otherwise you won't be able to compile anything you make. You can download it from the github at https://github.com/CamelCaseCam/GIL

## Release Notes

### 1.0.0

Initial release of GIL Syntax Highlighting for GIL 1.0
